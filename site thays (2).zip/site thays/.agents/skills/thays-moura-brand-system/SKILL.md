---
name: thays-moura-brand-system
description: >-
  Use this skill whenever designing, styling, or creating UI tokens and components
  for Thays Moura's nutritionist website to enforce her authentic organic-editorial
  brand identity extracted from her logo, photos, and visual direction.
---

# Thays Moura — Brand & Design System

## 1. Paleta de Cores Oficial (Branco Clean + Verde Oliva + Escuro)
Fundo clean em branco puro alternado com superfícies quentes suaves e o verde-oliva autêntico da marca. Nunca misture cinzas azulados frios ou roxos genéricos.

- `--bg-base`: `#FFFFFF` (fundo branco clean principal)
- `--bg-surface`: `#F6F4EF` (off-white linho sutil apenas para cards/destaques leves)
- `--bg-olive`: `#404727` (verde-oliva exato de `fotos/download.png` / `#3F4634` dos botões, usado no bloco de destaque do Método e CTAs primários)
- `--bg-olive-dark`: `#2F351D` (verde-oliva profundo para rodapé e hovers de contraste)
- `--text-primary`: `#1F2418` (cor escura grafite-oliva de alto contraste para títulos e corpo)
- `--text-muted`: `#5B6150` (texto secundário legível em fundo branco)
- `--border-subtle`: `rgba(64, 71, 39, 0.12)`

## 2. Tipografia Editorial
- **Display / Headings:** Sans-serif limpa e precisa (*Plus Jakarta Sans*) combinada com **serifa itálica expressiva** (*Cormorant Garamond* ou *Instrument Serif*) apenas nas palavras-chave emocionais dos títulos (`tracking: -0.02em`).
- **Corpo & UI:** *Plus Jakarta Sans*, `leading-relaxed` (`1.65`–`1.75`) e contraste mínimo WCAG AA (`>= 4.5:1`).

## 3. Tratamento Fotográfico e Geometria
- **Preservar o contexto orgânico:** As fotos em `fotos/` têm luz natural quente em sofá de linho; aplique molduras com cantos arredondados concêntricos (`R_ext = R_int + Padding`) e sombras ambientais sutis (`rgba(31, 36, 24, 0.08)`).
- **Pontuação:** Evitar uso excessivo ou decorativo de travessões (`—`) na copy visível ao usuário.
