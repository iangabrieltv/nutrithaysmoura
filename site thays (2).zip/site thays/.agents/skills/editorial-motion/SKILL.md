---
name: editorial-motion
description: >-
  Use this skill when implementing animations, scroll reveals, sticky scroll
  steppers, marquees, accordions, or tactile micro-interactions in Thays Moura's
  website so motion feels organic, editorial, performant, and accessible.
---

# Editorial Motion — Animações Orgânicas e Sticky Scroll Stepper

## 1. Sticky Scroll-Pinned Stepper (Seção "Como Funciona o Acompanhamento")
- **Estrutura de DOM:** Container pai com altura estendida (`h-[320vh]` no desktop / altura proporcional no mobile) contendo um wrapper interno `sticky top-0 min-h-screen flex items-center`.
- **Mapeamento Bidirecional (`useScroll` + `useTransform` / `useMotionValueEvent`):**
  - Mapeie o progresso `scrollYProgress` (`0` a `1`) do container pai em 4 faixas para as etapas `01`, `02`, `03` e `04`.
  - Título, subtítulo e indicador de progresso (`01 / 04`) permanecem visíveis dentro do bloco verde `#404727`.
  - **Transição vertical limpa:** Ao rolar para baixo, a etapa ativa sobe e esmaece (`y: 0 -> -28px, opacity: 1 -> 0`) enquanto a próxima entra por baixo (`y: 28px -> 0, opacity: 0 -> 1`). Ao rolar para cima, o fluxo inverte exatamente (`04 -> 03 -> 02 -> 01`) antes de sair da seção.
  - Em `prefers-reduced-motion: reduce`, renderize as 4 etapas em lista limpa acessível sem trava de scroll.

## 2. Princípios Gerais
- **Propriedades GPU-only:** Anime apenas `transform` e `opacity`.
- **Curva:** `cubic-bezier(0.22, 1, 0.36, 1)` (`450ms–650ms` para reveals; `150ms–200ms` para hovers táteis com `active:scale-[0.98]`).
- **Scroll Reveals (`viewport={{ once: true, amount: 0.2 }}`):** Nunca re-esconda elementos fora do stepper.
