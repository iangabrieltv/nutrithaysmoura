---
name: editorial-nutrition-ux
description: >-
  Use this skill when architecting page sections, interactive flows, FAQs,
  consultation steps, and conversion CTAs for Thays Moura's nutritionist site
  using bespoke editorial patterns instead of generic SaaS templates.
---

# Editorial Nutrition UX — Arquitetura e Conversão

## 1. Ritmo de Seções (Branco Clean + Contraste Verde Oliva)
1. **Header Cápsula / Clean:** Logo oficial à esquerda, links âncora no centro, CTA de WhatsApp em verde oliva à direita.
2. **Hero Assimétrico:** Eyebrow `Maceió · Atendimento Online`, headline com itálico serifado, subheadline direta sem travessões, 2 CTAs e prova social do Google (`5,0 ★ · 13 avaliações`) sem expor CRN no Hero.
3. **Como Posso Te Ajudar (Lista Editorial em Linhas):** Divisores finos em `#404727/12`, ícone de traço único (`1.5px`), título à esquerda e benefício prático à direita.
4. **O Método + Como Funciona (Bloco Verde `#404727` com Sticky Scroll Stepper):** Título e subtítulo fixos na viewport enquanto o usuário rola pelas 4 etapas (`01` a `04`), exibindo uma etapa por vez com transição bidirecional (descendo e subindo).
5. **Diferenciais (Split Assimétrico com foto da caneca T.M):** Foto ancorada à esquerda + lista limpa dos diferenciais à direita.
6. **Planos de Acompanhamento (Mensal e Trimestral):** Cards limpos com hierarquia visual destacando o Trimestral, sem listar formas de pagamento abaixo (formas de pagamento ficam no FAQ).
7. **Avaliações do Google:** Badge `Google ★★★★★ · 5,0 de 5 (13 avaliações)` + depoimentos reais.
8. **Sobre Mim:** História humana, pós-graduação e registro `CRN6-49792` com retrato.
9. **Localização em Maceió:** Endereço exato (`Galeria Alberto Torres, Av. Luiz Ramalho de Castro, 1459, Jatiúca, Maceió - AL, 57036-380`) + menção concisa ao atendimento online, sem explicações óbvias.
10. **FAQ Split (incluindo Formas de Pagamento) + CTA Final + Rodapé.**
