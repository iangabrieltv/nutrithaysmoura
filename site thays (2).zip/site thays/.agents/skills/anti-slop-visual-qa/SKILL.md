---
name: anti-slop-visual-qa
description: >-
  Use this skill after building or modifying any page or component in this workspace
  to audit against generic AI clichés, verify visual craft, responsive layout, and
  accessibility in the browser.
---

# Anti-Slop Visual QA Checklist

Antes de dar qualquer entrega de frontend como concluída:

1. **Teste Anti-Template:**
   - Alguma seção usa 3 cards centralizados idênticos sem necessidade? Se sim, converta em lista editorial ou grid assimétrico.
   - Os raios de borda internos e externos respeitam `R_externo = R_interno + Padding`?
   - As bordas usam `ring-1` translúcido ou sombra difusa em vez de linhas pretas/cinzas duras?
2. **Tipografia e Alinhamento Óptico:**
   - Ícones estão todos com a mesma família e espessura de traço (`1.5px`)?
   - Badges, pílulas e botões têm alinhamento óptico vertical real?
3. **Verificação em Viewport Real (Mobile `375px` e Desktop `1440px`):**
   - Zero overflow horizontal (`scrollWidth <= clientWidth`).
   - Imagens locais carregam nítidas, com `object-cover` / `object-top` preservando o rosto da Thays Moura sem cortes na testa/olhos.
   - Todos os links de âncora, acordeões e botões de WhatsApp respondem corretamente.
