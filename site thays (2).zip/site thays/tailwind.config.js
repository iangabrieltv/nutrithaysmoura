/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        olive: {
          DEFAULT: '#404727',
          dark: '#2F351D',
          light: '#6B7A45',
        },
        cream: {
          DEFAULT: '#F6F4EF',
          warm: '#F4F0E8',
        },
        forest: '#1F2418',
        muted: '#5B6150',
        border: 'rgba(64,71,39,0.12)',
      },
      fontFamily: {
        display: ['"Cormorant Garamond"', 'Georgia', 'serif'],
        sans: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
      },
      letterSpacing: {
        eyebrow: '0.12em',
      },
    },
  },
  plugins: [],
}
