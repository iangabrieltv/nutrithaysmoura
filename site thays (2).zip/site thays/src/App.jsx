import Header from './components/Header'
import Hero from './components/Hero'
import Marquee from './components/Marquee'
import ComoAjudo from './components/ComoAjudo'
import Metodo from './components/Metodo'
import Diferenciais from './components/Diferenciais'
import Planos from './components/Planos'
import Avaliacoes from './components/Avaliacoes'
import Sobre from './components/Sobre'
import Localizacao from './components/Localizacao'
import FAQ from './components/FAQ'
import CTAFinal from './components/CTAFinal'
import Footer from './components/Footer'

export default function App() {
  return (
    <div className="bg-white">
      <Header />
      <main>
        <Hero />
        <Marquee />
        <ComoAjudo />
        <Metodo />
        <Diferenciais />
        <Planos />
        <Avaliacoes />
        <Sobre />
        <Localizacao />
        <FAQ />
        <CTAFinal />
      </main>
      <Footer />
    </div>
  )
}
