const WA_LINK = 'https://wa.me/5582981316753?text=Ol%C3%A1!%20Quero%20agendar%20uma%20consulta.'

export default function Footer() {
  return (
    <footer className="bg-olive-dark text-white/70 py-16" role="contentinfo">
      <div className="max-w-6xl mx-auto px-5 sm:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-10 mb-12">

          {/* Brand */}
          <div>
            <img
              src="/logo.png"
              alt="Thays Moura Nutricionista"
              className="h-9 w-auto mb-4 brightness-0 invert opacity-90"
            />
            <p className="text-sm leading-relaxed">
              Nutrição Clínica, Esportiva e Saúde da Mulher.<br />
              Maceió e atendimento online.
            </p>
            <p className="text-xs mt-3 text-white/40">CRN6-49792</p>
          </div>

          {/* Links */}
          <div>
            <p className="text-xs font-semibold tracking-widest uppercase text-white/40 mb-4">Navegação</p>
            <ul className="space-y-2.5 text-sm" role="list">
              {[
                { label: 'Como ajudo', href: '#como-ajudo' },
                { label: 'O Método', href: '#metodo' },
                { label: 'Planos', href: '#planos' },
                { label: 'Avaliações', href: '#avaliacoes' },
                { label: 'Sobre', href: '#sobre' },
                { label: 'FAQ', href: '#faq' },
              ].map((l) => (
                <li key={l.href}>
                  <a href={l.href} className="hover:text-white transition-colors">
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contato */}
          <div>
            <p className="text-xs font-semibold tracking-widest uppercase text-white/40 mb-4">Contato</p>
            <ul className="space-y-3 text-sm" role="list">
              <li>
                <a
                  href={WA_LINK}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors flex items-center gap-2"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
                    <path d="M12 0C5.373 0 0 5.373 0 12c0 2.136.561 4.14 1.535 5.874L.057 23.882a.75.75 0 0 0 .921.921l6.138-1.489A11.943 11.943 0 0 0 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.75a9.75 9.75 0 0 1-4.986-1.364l-.358-.214-3.714.9.925-3.633-.234-.375A9.75 9.75 0 1 1 12 21.75z"/>
                  </svg>
                  +55 (82) 98131-6753
                </a>
              </li>
              <li>
                <a
                  href="mailto:thaysmoura.nutri@gmail.com"
                  className="hover:text-white transition-colors"
                >
                  thaysmoura.nutri@gmail.com
                </a>
              </li>
              <li>
                <a
                  href="https://instagram.com/thaysmouranutri"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-white transition-colors"
                >
                  @thaysmouranutri
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/10 pt-8 flex flex-col sm:flex-row justify-between items-center gap-3 text-xs text-white/35">
          <p>© {new Date().getFullYear()} Thays Moura. Todos os direitos reservados.</p>
          <p>CRN6-49792 · Nutrição Clínica e Esportiva</p>
        </div>
      </div>
    </footer>
  )
}
