import { useRef, useState, useEffect } from 'react'
import { motion, useScroll, useTransform, useMotionValueEvent, AnimatePresence } from 'framer-motion'

const steps = [
  {
    num: '01',
    titulo: 'Escuta e Anamnese',
    descricao: 'Mapeamos seu histórico de saúde, rotina, horários, exames, preferências alimentares e queixas específicas. Essa é a base de tudo — sem pressa e sem julgamento.',
  },
  {
    num: '02',
    titulo: 'Avaliação Completa',
    descricao: 'Analisamos composição corporal, medidas e exames laboratoriais para enxergar o que seu corpo realmente precisa. Os dados orientam cada decisão clínica.',
  },
  {
    num: '03',
    titulo: 'Plano Sob Medida',
    descricao: 'Você recebe um plano alimentar estruturado para a sua realidade, com opções práticas e substituições inteligentes. Nada de modelo genérico — tudo pensado para a sua rotina.',
  },
  {
    num: '04',
    titulo: 'Acompanhamento Contínuo',
    descricao: 'Suporte próximo entre as consultas para tirar dúvidas e ajustar a rota conforme seu corpo evolui. Constância é o que transforma resultado pontual em mudança real.',
  },
]

function usePrefersReducedMotion() {
  const [prefers, setPrefers] = useState(false)
  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)')
    setPrefers(mq.matches)
    const handler = (e) => setPrefers(e.matches)
    mq.addEventListener('change', handler)
    return () => mq.removeEventListener('change', handler)
  }, [])
  return prefers
}

export default function Metodo() {
  const reduced = usePrefersReducedMotion()
  const containerRef = useRef(null)
  const [activeStep, setActiveStep] = useState(0)

  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start start', 'end end'],
  })

  useMotionValueEvent(scrollYProgress, 'change', (val) => {
    // 4 steps: each takes 25% of scroll
    const idx = Math.min(3, Math.floor(val * 4))
    setActiveStep(idx)
  })

  if (reduced) {
    return (
      <section id="metodo" className="bg-olive py-24 sm:py-32" aria-label="O Método">
        <div className="max-w-6xl mx-auto px-5 sm:px-8">
          <p className="eyebrow text-white/60 mb-3">O MÉTODO DE ACOMPANHAMENTO</p>
          <h2 className="font-display text-4xl sm:text-5xl font-semibold text-white mb-4 max-w-2xl leading-tight">
            Um processo claro para gerar constância e resultado real
          </h2>
          <p className="text-white/70 text-base sm:text-lg max-w-xl mb-16 leading-relaxed">
            Dieta perfeita no papel não funciona se não cabe na sua segunda-feira. O acompanhamento une evidência científica, leitura individual do seu momento e suporte próximo entre consultas.
          </p>
          <div className="grid gap-8 sm:grid-cols-2">
            {steps.map((s) => (
              <div key={s.num} className="border border-white/10 rounded-2xl p-7">
                <span className="text-xs font-bold tracking-widest text-white/40 mb-3 block">{s.num}</span>
                <h3 className="font-display text-2xl font-semibold text-white mb-3">{s.titulo}</h3>
                <p className="text-white/70 text-sm leading-relaxed">{s.descricao}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    )
  }

  return (
    <section
      ref={containerRef}
      id="metodo"
      style={{ height: '350vh' }}
      className="relative"
      aria-label="O Método"
    >
      <div className="sticky top-0 h-screen bg-olive flex flex-col justify-center overflow-hidden">
        <div className="max-w-6xl mx-auto px-5 sm:px-8 w-full">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center min-h-screen py-24">

            {/* Left — static title */}
            <div>
              <p className="eyebrow text-white/60 mb-4">O MÉTODO DE ACOMPANHAMENTO</p>
              <h2 className="font-display text-4xl sm:text-5xl font-semibold text-white mb-6 leading-tight">
                Um processo claro para gerar constância e resultado real
              </h2>
              <p className="text-white/70 text-base leading-relaxed mb-10">
                Dieta perfeita no papel não funciona se não cabe na sua segunda-feira. O acompanhamento une evidência científica, leitura individual do seu momento e suporte próximo entre consultas.
              </p>

              {/* Step indicators */}
              <div className="flex gap-3" aria-hidden="true">
                {steps.map((s, i) => (
                  <div
                    key={s.num}
                    className={`h-0.5 flex-1 rounded-full transition-all duration-500 ${
                      i <= activeStep ? 'bg-white' : 'bg-white/20'
                    }`}
                  />
                ))}
              </div>
            </div>

            {/* Right — animated step */}
            <div className="relative h-72 sm:h-80 flex items-center" aria-live="polite" aria-atomic="true">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeStep}
                  initial={{ opacity: 0, y: 32 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -32 }}
                  transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
                  className="absolute inset-0 flex flex-col justify-center"
                >
                  <span className="text-6xl sm:text-7xl font-display font-semibold text-white/10 mb-4 leading-none select-none">
                    {steps[activeStep].num}
                  </span>
                  <h3 className="font-display text-3xl sm:text-4xl font-semibold text-white mb-4 leading-tight">
                    {steps[activeStep].titulo}
                  </h3>
                  <p className="text-white/75 text-base sm:text-lg leading-relaxed max-w-md">
                    {steps[activeStep].descricao}
                  </p>
                </motion.div>
              </AnimatePresence>
            </div>

          </div>
        </div>
      </div>
    </section>
  )
}
