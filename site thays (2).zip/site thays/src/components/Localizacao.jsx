import { motion } from 'framer-motion'
import { MapPin } from 'lucide-react'

const MAPS_LINK = 'https://maps.google.com/?q=Galeria+Alberto+Torres+Av.+Luiz+Ramalho+de+Castro+1459+Jatiuca+Maceio+AL'

export default function Localizacao() {
  return (
    <section id="localizacao" className="bg-white py-24 sm:py-32" aria-label="Localização">
      <div className="max-w-6xl mx-auto px-5 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">

          {/* Left — consultório photo */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <img
              src="/consultorio.jpg"
              alt="Consultório da Thays Moura em Jatiúca, Maceió — piso em chevron, cadeiras âmbar, mesa branca"
              className="w-full rounded-[2rem] object-cover shadow-[0_12px_48px_rgba(64,71,39,0.12)]"
              style={{ aspectRatio: '4/3' }}
            />
          </motion.div>

          {/* Right — info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <p className="eyebrow mb-3">Localização</p>
            <h2 className="font-display text-4xl sm:text-5xl font-semibold text-forest mb-6 leading-tight">
              Presencial em Maceió<br />e online para todo o Brasil
            </h2>

            <div className="space-y-5 mb-10">
              <div className="flex gap-4 items-start">
                <div className="w-10 h-10 rounded-full bg-cream flex items-center justify-center shrink-0">
                  <MapPin size={18} className="text-olive" aria-hidden="true" />
                </div>
                <div>
                  <p className="font-semibold text-forest mb-0.5">Jatiúca, Maceió</p>
                  <p className="text-muted text-sm leading-relaxed">
                    Galeria Alberto Torres<br />
                    Av. Luiz Ramalho de Castro, 1459<br />
                    Jatiúca, Maceió - AL · 57036-380
                  </p>
                </div>
              </div>

              <div className="flex gap-4 items-start">
                <div className="w-10 h-10 rounded-full bg-cream flex items-center justify-center shrink-0">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="text-olive" aria-hidden="true">
                    <rect x="2" y="3" width="20" height="14" rx="2" /><path d="m8 21 4-4 4 4"/><path d="M12 17v4"/>
                  </svg>
                </div>
                <div>
                  <p className="font-semibold text-forest mb-0.5">Atendimento Online</p>
                  <p className="text-muted text-sm">Para todo o Brasil, via teleconsulta.</p>
                </div>
              </div>
            </div>

            <a
              href={MAPS_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 border border-olive/25 text-olive font-semibold text-sm px-6 py-3 rounded-full hover:bg-cream transition-colors focus-visible:outline-2 focus-visible:outline-olive"
            >
              <MapPin size={15} aria-hidden="true" />
              Ver no mapa
            </a>
          </motion.div>

        </div>
      </div>
    </section>
  )
}
