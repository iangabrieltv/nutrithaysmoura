import { useState, useEffect } from 'react'
import { Menu, X } from 'lucide-react'

const WA_LINK = 'https://wa.me/5582981316753?text=Ol%C3%A1!%20Quero%20agendar%20uma%20consulta.'

const navLinks = [
  { label: 'Como ajudo', href: '#como-ajudo' },
  { label: 'Sobre', href: '#sobre' },
  { label: 'Acompanhamento', href: '#metodo' },
  { label: 'Planos', href: '#planos' },
]

export default function Header() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'py-3' : 'py-5'
      }`}
    >
      <div className="max-w-6xl mx-auto px-5 sm:px-8">
        <div
          className={`flex items-center justify-between rounded-full px-5 py-3 transition-all duration-300 ${
            scrolled
              ? 'bg-white/95 backdrop-blur-sm shadow-[0_2px_24px_rgba(64,71,39,0.10)]'
              : 'bg-white/80 backdrop-blur-sm shadow-[0_1px_12px_rgba(64,71,39,0.06)]'
          }`}
        >
          {/* Logo */}
          <a href="#" aria-label="Thays Moura Nutricionista — início">
            <img
              src="/logo.png"
              alt="Thays Moura Nutricionista"
              className="h-9 w-auto"
            />
          </a>

          {/* Nav desktop */}
          <nav className="hidden md:flex items-center gap-7" aria-label="Navegação principal">
            {navLinks.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="text-sm font-medium text-forest/80 hover:text-olive transition-colors"
              >
                {l.label}
              </a>
            ))}
          </nav>

          {/* CTA + hamburger */}
          <div className="flex items-center gap-3">
            <a
              href={WA_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden md:inline-flex items-center gap-2 bg-olive text-white text-sm font-semibold px-5 py-2.5 rounded-full hover:bg-olive-dark transition-colors focus-visible:outline-2 focus-visible:outline-olive"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
                <path d="M12 0C5.373 0 0 5.373 0 12c0 2.136.561 4.14 1.535 5.874L.057 23.882a.75.75 0 0 0 .921.921l6.138-1.489A11.943 11.943 0 0 0 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.75a9.75 9.75 0 0 1-4.986-1.364l-.358-.214-3.714.9.925-3.633-.234-.375A9.75 9.75 0 1 1 12 21.75z"/>
              </svg>
              Agendar consulta
            </a>
            <button
              className="md:hidden p-2 text-forest rounded-full hover:bg-cream transition-colors"
              aria-label={open ? 'Fechar menu' : 'Abrir menu'}
              aria-expanded={open}
              onClick={() => setOpen(!open)}
            >
              {open ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {open && (
          <div className="mt-2 md:hidden bg-white rounded-2xl shadow-lg p-6 flex flex-col gap-4">
            {navLinks.map((l) => (
              <a
                key={l.href}
                href={l.href}
                onClick={() => setOpen(false)}
                className="text-base font-medium text-forest hover:text-olive transition-colors"
              >
                {l.label}
              </a>
            ))}
            <a
              href={WA_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2 inline-flex items-center justify-center gap-2 bg-olive text-white text-sm font-semibold px-5 py-3 rounded-full hover:bg-olive-dark transition-colors"
            >
              Agendar consulta
            </a>
          </div>
        )}
      </div>
    </header>
  )
}
