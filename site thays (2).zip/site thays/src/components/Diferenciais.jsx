import { motion } from 'framer-motion'
import { CheckCircle2 } from 'lucide-react'

const diferenciais = [
  { titulo: 'Atendimento humanizado', descricao: 'Escuta ativa e acolhimento em cada etapa do processo.' },
  { titulo: 'Baseada em evidências', descricao: 'Condutas fundamentadas em ciência atualizada e ética clínica.' },
  { titulo: 'Plano individualizado', descricao: 'Nada de modelo pronto — cada plano é único e feito para você.' },
  { titulo: 'Suporte contínuo', descricao: 'Contato entre consultas para dúvidas, ajustes e acompanhamento próximo.' },
  { titulo: 'Resultados duradouros', descricao: 'Foco em manutenção, não só na perda inicial. Resultado que fica.' },
]

export default function Diferenciais() {
  return (
    <section className="bg-white py-24 sm:py-32" aria-label="Por que escolher este acompanhamento">
      <div className="max-w-6xl mx-auto px-5 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-20 items-center">

          {/* Left — image */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="absolute -inset-4 bg-cream rounded-[2rem]" aria-hidden="true" />
            <img
              src="/thays-mug.png"
              alt="Thays Moura em consulta, caneca verde T.M."
              className="relative z-10 w-full max-w-sm mx-auto rounded-[1.5rem] object-cover shadow-[0_12px_48px_rgba(64,71,39,0.16)]"
              style={{ aspectRatio: '4/5' }}
            />
          </motion.div>

          {/* Right — diferenciais */}
          <div>
            <motion.p
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="eyebrow mb-3"
            >
              Por que escolher este acompanhamento
            </motion.p>
            <motion.h2
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.08 }}
              className="font-display text-4xl sm:text-5xl font-semibold text-forest mb-10 leading-tight"
            >
              Diferenciais
            </motion.h2>

            <ul className="space-y-6" role="list">
              {diferenciais.map((d, i) => (
                <motion.li
                  key={d.titulo}
                  initial={{ opacity: 0, x: 16 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: '-40px' }}
                  transition={{ duration: 0.45, delay: i * 0.08 }}
                  className="flex gap-4"
                >
                  <CheckCircle2
                    size={22}
                    className="text-olive shrink-0 mt-0.5"
                    aria-hidden="true"
                  />
                  <div>
                    <h3 className="font-semibold text-forest mb-1">{d.titulo}</h3>
                    <p className="text-muted text-sm leading-relaxed">{d.descricao}</p>
                  </div>
                </motion.li>
              ))}
            </ul>
          </div>

        </div>
      </div>
    </section>
  )
}
