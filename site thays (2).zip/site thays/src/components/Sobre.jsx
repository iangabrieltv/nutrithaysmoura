import { motion } from 'framer-motion'

const WA_LINK = 'https://wa.me/5582981316753?text=Ol%C3%A1!%20Quero%20saber%20mais%20sobre%20o%20acompanhamento.'

export default function Sobre() {
  return (
    <section id="sobre" className="bg-cream py-24 sm:py-32" aria-label="Sobre Thays Moura">
      <div className="max-w-6xl mx-auto px-5 sm:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-center">

          {/* Left — copy */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <p className="eyebrow mb-3">Sobre</p>
            <h2 className="font-display text-5xl sm:text-6xl font-semibold text-forest mb-2 leading-tight">
              Thays Moura
            </h2>
            <p className="text-olive text-sm font-medium mb-8">
              Nutricionista Clínica, Esportiva e Saúde da Mulher · CRN6-49792
            </p>

            <div className="space-y-4 text-muted text-base leading-relaxed mb-10">
              <p>
                Sou nutricionista clínica e esportiva. Atuo com foco na construção de uma alimentação
                que funcione na prática — respeitando sua rotina, seus gostos e seus objetivos.
              </p>
              <p>
                Sem dietas extremas, sem planos engessados. Com estratégia, constância e acompanhamento
                próximo, porque resultado real vem de hábito, não de sacrifício.
              </p>
            </div>

            {/* Credentials grid */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-10">
              {[
                { label: 'Formação', value: 'Nutrição Clínica e Esportiva' },
                { label: 'Pós-graduanda', value: 'Nutrição Estética, Esportiva e Saúde da Mulher' },
                { label: 'Atendimento', value: 'Presencial (Jatiúca, Serraria) e Online' },
              ].map((item) => (
                <div key={item.label} className="bg-white rounded-2xl p-5 border border-olive/8">
                  <p className="text-xs font-semibold text-olive/60 uppercase tracking-wider mb-1">{item.label}</p>
                  <p className="text-sm font-medium text-forest leading-snug">{item.value}</p>
                </div>
              ))}
            </div>

            <a
              href={WA_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-olive text-white font-semibold text-sm px-7 py-3.5 rounded-full hover:bg-olive-dark transition-colors shadow-[0_4px_16px_rgba(64,71,39,0.2)] focus-visible:outline-2 focus-visible:outline-olive"
            >
              Falar com a Thays
            </a>
          </motion.div>

          {/* Right — portrait */}
          <motion.div
            initial={{ opacity: 0, scale: 0.97 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="relative"
          >
            <div className="relative mx-auto max-w-sm lg:max-w-full">
              <div
                className="absolute inset-0 rounded-[2rem] bg-olive/8"
                style={{ transform: 'scale(1.05) rotate(2deg)' }}
                aria-hidden="true"
              />
              <img
                src="/thays-portrait.jpeg"
                alt="Thays Moura, nutricionista em Maceió"
                className="relative z-10 w-full rounded-[2rem] object-cover object-top shadow-[0_16px_60px_rgba(64,71,39,0.14)]"
                style={{ aspectRatio: '3/4' }}
              />
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  )
}
