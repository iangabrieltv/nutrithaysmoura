import { motion } from 'framer-motion'

const WA_LINK = 'https://wa.me/5582981316753?text=Ol%C3%A1!%20Quero%20saber%20mais%20sobre%20os%20planos%20de%20acompanhamento.'

const planos = [
  {
    id: 'mensal',
    tag: 'Mensal',
    subtag: 'Ideal para começar',
    descricao: 'O primeiro passo para organizar a alimentação com orientação profissional.',
    inclui: [
      '1 consulta mensal (60 min)',
      'Plano alimentar personalizado',
      'Suporte por mensagem',
      'Revisão de exames',
    ],
    destaque: false,
  },
  {
    id: 'trimestral',
    tag: 'Trimestral',
    subtag: 'Mais resultado',
    descricao: 'Para quem quer consistência, evolução monitorada e ajustes contínuos ao longo do tempo.',
    inclui: [
      '3 consultas (mensais)',
      'Plano alimentar + revisões',
      'Suporte contínuo por mensagem',
      'Revisão de exames',
      'Reavaliação de composição corporal',
    ],
    destaque: true,
  },
]

export default function Planos() {
  return (
    <section id="planos" className="bg-cream py-24 sm:py-32" aria-label="Planos de acompanhamento">
      <div className="max-w-6xl mx-auto px-5 sm:px-8">
        <div className="text-center mb-14">
          <p className="eyebrow mb-3">Planos</p>
          <h2 className="font-display text-4xl sm:text-5xl font-semibold text-forest mb-4 leading-tight">
            Planos de acompanhamento
          </h2>
          <p className="text-muted text-base max-w-md mx-auto leading-relaxed">
            Escolha o momento certo para você e fale pelo WhatsApp para saber mais detalhes.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 max-w-3xl mx-auto">
          {planos.map((plano, i) => (
            <motion.div
              key={plano.id}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className={`relative rounded-3xl p-8 flex flex-col ${
                plano.destaque
                  ? 'bg-olive text-white shadow-[0_12px_48px_rgba(64,71,39,0.28)]'
                  : 'bg-white border border-olive/10 shadow-sm'
              }`}
            >
              {plano.destaque && (
                <span className="absolute -top-3 left-6 bg-white text-olive text-xs font-bold tracking-widest uppercase px-4 py-1.5 rounded-full shadow-sm">
                  Mais popular
                </span>
              )}

              <div className="mb-6">
                <p className={`text-xs font-semibold tracking-widest uppercase mb-2 ${plano.destaque ? 'text-white/60' : 'text-olive/60'}`}>
                  {plano.subtag}
                </p>
                <h3 className={`font-display text-3xl font-semibold ${plano.destaque ? 'text-white' : 'text-forest'}`}>
                  {plano.tag}
                </h3>
                <p className={`text-sm mt-3 leading-relaxed ${plano.destaque ? 'text-white/70' : 'text-muted'}`}>
                  {plano.descricao}
                </p>
              </div>

              <ul className="space-y-3 mb-8 flex-1" role="list">
                {plano.inclui.map((item) => (
                  <li key={item} className="flex items-start gap-2.5">
                    <svg className={`w-4 h-4 mt-0.5 shrink-0 ${plano.destaque ? 'text-white/70' : 'text-olive'}`} viewBox="0 0 16 16" fill="none" aria-hidden="true">
                      <circle cx="8" cy="8" r="7.5" stroke="currentColor" strokeOpacity="0.3" />
                      <path d="M5 8l2 2 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                    <span className={`text-sm ${plano.destaque ? 'text-white/85' : 'text-muted'}`}>{item}</span>
                  </li>
                ))}
              </ul>

              <a
                href={WA_LINK}
                target="_blank"
                rel="noopener noreferrer"
                className={`inline-flex items-center justify-center gap-2 font-semibold text-sm px-6 py-3.5 rounded-full transition-colors focus-visible:outline-2 ${
                  plano.destaque
                    ? 'bg-white text-olive hover:bg-cream focus-visible:outline-white'
                    : 'bg-olive text-white hover:bg-olive-dark focus-visible:outline-olive'
                }`}
              >
                Falar pelo WhatsApp
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
