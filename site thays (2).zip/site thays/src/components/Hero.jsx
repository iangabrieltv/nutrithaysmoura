import { motion } from 'framer-motion'

const WA_LINK = 'https://wa.me/5582981316753?text=Ol%C3%A1!%20Quero%20agendar%20uma%20consulta.'

export default function Hero() {
  return (
    <section className="relative min-h-screen bg-white flex items-center pt-24 pb-16 overflow-hidden" aria-label="Apresentação">
      <div className="max-w-6xl mx-auto px-5 sm:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">

          {/* Left — copy */}
          <div className="order-2 lg:order-1">
            <motion.p
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="eyebrow mb-5"
            >
              Maceió · Atendimento Online
            </motion.p>

            <motion.h1
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="font-display text-[2.6rem] sm:text-5xl lg:text-6xl leading-[1.08] font-semibold text-forest mb-6"
            >
              Seu corpo muda{' '}
              <span className="block">de fase.{' '}
                <em className="italic text-olive not-italic font-semibold">
                  Sua nutrição
                </em>
              </span>
              <em className="italic text-olive not-italic font-semibold">
                também precisa mudar.
              </em>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-muted text-base sm:text-lg leading-relaxed mb-10 max-w-lg"
            >
              Acompanhamento nutricional individualizado para emagrecimento, hipertrofia,
              lipedema, endometriose, equilíbrio hormonal e uso de medicações GLP-1 —
              com ciência, escuta e resultado que se sustenta.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="flex flex-wrap gap-3"
            >
              <a
                href={WA_LINK}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-olive text-white font-semibold text-sm px-7 py-3.5 rounded-full hover:bg-olive-dark transition-colors shadow-[0_4px_16px_rgba(64,71,39,0.25)] focus-visible:outline-2 focus-visible:outline-olive"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
                  <path d="M12 0C5.373 0 0 5.373 0 12c0 2.136.561 4.14 1.535 5.874L.057 23.882a.75.75 0 0 0 .921.921l6.138-1.489A11.943 11.943 0 0 0 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.75a9.75 9.75 0 0 1-4.986-1.364l-.358-.214-3.714.9.925-3.633-.234-.375A9.75 9.75 0 1 1 12 21.75z"/>
                </svg>
                Agendar consulta
              </a>
              <a
                href="#metodo"
                className="inline-flex items-center gap-2 border border-olive/30 text-olive font-semibold text-sm px-7 py-3.5 rounded-full hover:bg-cream transition-colors focus-visible:outline-2 focus-visible:outline-olive"
              >
                Como funciona
              </a>
            </motion.div>

            {/* Credentials row */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.5 }}
              className="mt-10 flex flex-wrap gap-5 text-sm text-muted"
            >
              <span className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-olive/60 inline-block" />
                Nutrição Clínica e Esportiva
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-olive/60 inline-block" />
                Presencial e Online
              </span>
            </motion.div>
          </div>

          {/* Right — portrait */}
          <motion.div
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, delay: 0.15 }}
            className="order-1 lg:order-2 relative flex justify-center lg:justify-end"
          >
            <div className="relative">
              {/* Background organic shape */}
              <div
                className="absolute inset-0 rounded-[2rem] lg:rounded-[2.5rem] bg-cream"
                style={{ transform: 'scale(1.04) translateY(8px)', zIndex: 0 }}
              />
              <img
                src="/thays-portrait.jpeg"
                alt="Thays Moura, nutricionista clínica e esportiva em Maceió"
                className="relative z-10 w-full max-w-sm lg:max-w-md rounded-[2rem] lg:rounded-[2.5rem] object-cover object-top shadow-[0_16px_60px_rgba(64,71,39,0.18)]"
                style={{ aspectRatio: '3/4' }}
              />
              {/* Badge */}
              <div className="absolute z-20 bottom-5 left-5 bg-white rounded-2xl shadow-lg px-5 py-3">
                <p className="font-display text-lg font-semibold text-forest leading-tight">Nutrição</p>
                <p className="font-display text-lg font-semibold text-olive leading-tight">Clínica &amp; Esportiva</p>
              </div>
              {/* Google stars */}
              <div className="absolute z-20 top-5 right-5 bg-white rounded-xl shadow-md px-3 py-2 flex items-center gap-1.5">
                <span className="text-amber-400 text-sm leading-none">★★★★★</span>
                <span className="text-xs font-semibold text-forest">5,0</span>
              </div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  )
}
