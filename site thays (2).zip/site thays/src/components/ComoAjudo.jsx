import { motion } from 'framer-motion'

const servicos = [
  {
    numero: '01',
    titulo: 'Emagrecimento',
    descricao: 'Estratégia sustentável, sem restrição extrema, respeitando fome, saciedade e vida social.',
  },
  {
    numero: '02',
    titulo: 'Hipertrofia',
    descricao: 'Alimentação estruturada para ganho de massa magra alinhada ao seu treino e objetivo estético.',
  },
  {
    numero: '03',
    titulo: 'Lipedema',
    descricao: 'Conduta nutricional específica com foco em inflamação, retenção e qualidade de vida.',
  },
  {
    numero: '04',
    titulo: 'Endometriose',
    descricao: 'Nutrição anti-inflamatória para reduzir sintomas e apoiar o tratamento multidisciplinar.',
  },
  {
    numero: '05',
    titulo: 'Suporte GLP-1',
    descricao: 'Suporte nutricional durante o uso de Ozempic, Mounjaro, Wegovy e similares, com foco em preservar massa magra e amenizar efeitos colaterais.',
  },
  {
    numero: '06',
    titulo: 'Saúde hormonal',
    descricao: 'Nutrição que considera ciclo, TPM, tireoide e as fases da vida reprodutiva.',
  },
  {
    numero: '07',
    titulo: 'Performance',
    descricao: 'Nutrição esportiva para melhorar energia, recuperação e rendimento nos treinos.',
  },
  {
    numero: '08',
    titulo: 'Reeducação alimentar',
    descricao: 'Construção de hábitos reais e duradouros — sem dietas restritivas, sem culpa, com autonomia para manter os resultados a longo prazo.',
  },
]

function ServiceRow({ servico, index }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.5, delay: index * 0.06 }}
      className="group grid grid-cols-[2rem_1fr] sm:grid-cols-[3rem_1fr_1.5fr] gap-4 sm:gap-8 py-6 border-b border-olive/10 items-start sm:items-center cursor-default"
    >
      <span className="text-xs font-semibold text-olive/50 tracking-widest pt-1 sm:pt-0">
        {servico.numero}
      </span>
      <h3 className="font-display text-2xl sm:text-3xl font-semibold text-forest group-hover:text-olive transition-colors duration-300 leading-tight">
        {servico.titulo}
      </h3>
      <p className="col-span-2 sm:col-span-1 text-muted text-sm sm:text-base leading-relaxed">
        {servico.descricao}
      </p>
    </motion.div>
  )
}

export default function ComoAjudo() {
  return (
    <section id="como-ajudo" className="bg-white py-24 sm:py-32">
      <div className="max-w-6xl mx-auto px-5 sm:px-8">
        <div className="mb-14">
          <p className="eyebrow mb-3">Como posso te ajudar</p>
          <h2 className="font-display text-4xl sm:text-5xl font-semibold text-forest leading-tight max-w-xl">
            Áreas de atuação
          </h2>
        </div>
        <div>
          {servicos.map((s, i) => (
            <ServiceRow key={s.numero} servico={s} index={i} />
          ))}
        </div>
      </div>
    </section>
  )
}
