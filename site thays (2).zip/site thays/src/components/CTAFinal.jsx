import { motion } from 'framer-motion'

const WA_LINK = 'https://wa.me/5582981316753?text=Ol%C3%A1!%20Quero%20agendar%20uma%20consulta.'

export default function CTAFinal() {
  return (
    <section className="bg-olive py-24 sm:py-32" aria-label="Agende sua consulta">
      <div className="max-w-4xl mx-auto px-5 sm:px-8 text-center">
        <motion.p
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-xs font-semibold tracking-eyebrow uppercase text-white/50 mb-4"
        >
          Comece agora
        </motion.p>
        <motion.h2
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.08 }}
          className="font-display text-4xl sm:text-5xl lg:text-6xl font-semibold text-white leading-tight mb-6"
        >
          Pronta para uma alimentação<br className="hidden sm:block" /> que funciona de verdade?
        </motion.h2>
        <motion.p
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.15 }}
          className="text-white/70 text-base sm:text-lg max-w-lg mx-auto mb-10 leading-relaxed"
        >
          Agende sua consulta pelo WhatsApp e dê o primeiro passo para um acompanhamento que respeita quem você é.
        </motion.p>
        <motion.a
          href={WA_LINK}
          target="_blank"
          rel="noopener noreferrer"
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4, delay: 0.2 }}
          className="inline-flex items-center gap-2 bg-white text-olive font-bold text-sm px-8 py-4 rounded-full hover:bg-cream transition-colors shadow-[0_8px_32px_rgba(0,0,0,0.15)] focus-visible:outline-2 focus-visible:outline-white"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
            <path d="M12 0C5.373 0 0 5.373 0 12c0 2.136.561 4.14 1.535 5.874L.057 23.882a.75.75 0 0 0 .921.921l6.138-1.489A11.943 11.943 0 0 0 12 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.75a9.75 9.75 0 0 1-4.986-1.364l-.358-.214-3.714.9.925-3.633-.234-.375A9.75 9.75 0 1 1 12 21.75z"/>
          </svg>
          Agendar consulta pelo WhatsApp
        </motion.a>
      </div>
    </section>
  )
}
