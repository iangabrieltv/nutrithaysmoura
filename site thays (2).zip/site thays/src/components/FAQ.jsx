import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Plus } from 'lucide-react'

const faqs = [
  {
    pergunta: 'Quais são as formas de pagamento?',
    resposta: 'Aceito Pix, cartão de débito e cartão de crédito (parcelamento disponível). Fale pelo WhatsApp para verificar as condições atuais.',
  },
  {
    pergunta: 'O atendimento online funciona igual ao presencial?',
    resposta: 'Sim. A consulta online tem a mesma qualidade e duração do atendimento presencial. Utilizamos videochamada e você recebe o plano alimentar completo digitalmente.',
  },
  {
    pergunta: 'Com que frequência acontecem as consultas?',
    resposta: 'Depende do plano escolhido. No plano mensal, uma consulta por mês. No trimestral, uma consulta por mês ao longo de três meses, com suporte contínuo entre elas.',
  },
  {
    pergunta: 'Preciso levar exames na primeira consulta?',
    resposta: 'Não é obrigatório, mas se você já tiver exames recentes, ótimo — eles ajudam na avaliação inicial. Caso não tenha, podemos solicitar no decorrer do acompanhamento.',
  },
  {
    pergunta: 'Atende casos de lipedema e endometriose?',
    resposta: 'Sim. São áreas de atuação com condutas específicas, foco em anti-inflamatório e qualidade de vida. O acompanhamento considera as particularidades clínicas de cada condição.',
  },
  {
    pergunta: 'Como funciona o suporte entre consultas?',
    resposta: 'Pelo WhatsApp, dentro do horário de atendimento. Você pode tirar dúvidas sobre o plano, comunicar sintomas ou solicitar ajustes pontuais sem precisar esperar a próxima consulta.',
  },
  {
    pergunta: 'Atende uso de medicações GLP-1 (Ozempic, Wegovy, Mounjaro)?',
    resposta: 'Sim. O suporte nutricional durante o uso de GLP-1 é uma das especialidades do acompanhamento — com foco em preservar massa magra, garantir aporte nutricional adequado e minimizar efeitos colaterais.',
  },
]

function FAQItem({ item, index }) {
  const [open, setOpen] = useState(false)
  const id = `faq-${index}`

  return (
    <div className="border-b border-olive/10">
      <button
        id={`${id}-btn`}
        aria-expanded={open}
        aria-controls={`${id}-panel`}
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between gap-4 py-5 text-left group focus-visible:outline-2 focus-visible:outline-olive rounded"
      >
        <span className="font-medium text-forest text-base group-hover:text-olive transition-colors">
          {item.pergunta}
        </span>
        <span
          className={`shrink-0 w-7 h-7 rounded-full border border-olive/20 flex items-center justify-center transition-all duration-300 ${open ? 'bg-olive border-olive rotate-45' : ''}`}
          aria-hidden="true"
        >
          <Plus size={14} className={open ? 'text-white' : 'text-olive'} />
        </span>
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            id={`${id}-panel`}
            role="region"
            aria-labelledby={`${id}-btn`}
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden"
          >
            <p className="pb-5 text-muted text-sm leading-relaxed max-w-2xl">
              {item.resposta}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

export default function FAQ() {
  return (
    <section id="faq" className="bg-cream py-24 sm:py-32" aria-label="Perguntas frequentes">
      <div className="max-w-4xl mx-auto px-5 sm:px-8">
        <div className="mb-12">
          <p className="eyebrow mb-3">FAQ</p>
          <h2 className="font-display text-4xl sm:text-5xl font-semibold text-forest leading-tight">
            Perguntas frequentes
          </h2>
        </div>
        <div>
          {faqs.map((item, i) => (
            <FAQItem key={i} item={item} index={i} />
          ))}
        </div>
      </div>
    </section>
  )
}
