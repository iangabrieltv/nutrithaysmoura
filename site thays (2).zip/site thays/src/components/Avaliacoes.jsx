import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronLeft, ChevronRight } from 'lucide-react'

const REVIEW_LINK = 'https://search.google.com/local/writereview?placeid=ChIJi_2C4wpFAQcRsO5hvJQhFhI'

const fotos = [
  '/fotos-avaliacoes/IMG_9645.jpeg',
  '/fotos-avaliacoes/IMG_9646.jpeg',
  '/fotos-avaliacoes/IMG_9647.jpeg',
  '/fotos-avaliacoes/IMG_9648.jpeg',
  '/fotos-avaliacoes/IMG_9650.jpeg',
  '/fotos-avaliacoes/IMG_9651.jpeg',
]

export default function Avaliacoes() {
  const [current, setCurrent] = useState(0)

  const prev = () => setCurrent((c) => (c === 0 ? fotos.length - 1 : c - 1))
  const next = () => setCurrent((c) => (c === fotos.length - 1 ? 0 : c + 1))

  return (
    <section id="avaliacoes" className="bg-white py-24 sm:py-32" aria-label="Avaliações">
      <div className="max-w-6xl mx-auto px-5 sm:px-8">

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-14">
          <div>
            <p className="eyebrow mb-3">Avaliações</p>
            <h2 className="font-display text-4xl sm:text-5xl font-semibold text-forest leading-tight">
              Histórias reais de quem vive<br className="hidden sm:block" /> o acompanhamento
            </h2>
          </div>
          {/* Google badge */}
          <div className="flex items-center gap-3 shrink-0 bg-cream rounded-2xl px-5 py-3">
            <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            <div>
              <div className="flex items-center gap-1">
                <span className="text-amber-400 text-sm leading-none">★★★★★</span>
                <span className="text-sm font-bold text-forest ml-1">5,0</span>
              </div>
              <p className="text-xs text-muted">13 avaliações no Google</p>
            </div>
          </div>
        </div>

        {/* Photo carousel */}
        <div className="relative">
          {/* Mobile: single card carousel */}
          <div className="sm:hidden">
            <div className="relative overflow-hidden rounded-2xl aspect-[3/4] bg-cream">
              <AnimatePresence mode="wait">
                <motion.img
                  key={current}
                  src={fotos[current]}
                  alt={`Avaliação de paciente ${current + 1}`}
                  initial={{ opacity: 0, x: 40 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -40 }}
                  transition={{ duration: 0.35 }}
                  className="w-full h-full object-cover"
                />
              </AnimatePresence>
            </div>
            <div className="flex items-center justify-between mt-4">
              <button
                onClick={prev}
                className="p-3 border border-olive/15 rounded-full hover:bg-cream transition-colors"
                aria-label="Avaliação anterior"
              >
                <ChevronLeft size={18} className="text-olive" />
              </button>
              <span className="text-xs text-muted">{current + 1} / {fotos.length}</span>
              <button
                onClick={next}
                className="p-3 border border-olive/15 rounded-full hover:bg-cream transition-colors"
                aria-label="Próxima avaliação"
              >
                <ChevronRight size={18} className="text-olive" />
              </button>
            </div>
          </div>

          {/* Desktop: grid */}
          <div className="hidden sm:grid grid-cols-3 lg:grid-cols-6 gap-3">
            {fotos.map((src, i) => (
              <motion.div
                key={src}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.07 }}
                className={`rounded-2xl overflow-hidden bg-cream ${i === 0 ? 'col-span-2 row-span-1' : ''}`}
              >
                <img
                  src={src}
                  alt={`Resultado de paciente ${i + 1} acompanhada por Thays Moura`}
                  className="w-full h-full object-cover"
                  style={{ aspectRatio: i === 0 ? '1/1' : '3/4', minHeight: '220px' }}
                  loading="lazy"
                />
              </motion.div>
            ))}
          </div>
        </div>

        {/* CTA leave review */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mt-12 flex flex-col sm:flex-row items-center justify-between gap-6 border border-olive/10 rounded-2xl p-6 sm:p-8 bg-cream"
        >
          <div>
            <h3 className="font-display text-2xl font-semibold text-forest mb-1">Já fez acompanhamento com a Thays?</h3>
            <p className="text-muted text-sm">Sua avaliação ajuda outras pessoas a encontrarem a orientação certa.</p>
          </div>
          <a
            href={REVIEW_LINK}
            target="_blank"
            rel="noopener noreferrer"
            className="shrink-0 inline-flex items-center gap-2 border-2 border-olive text-olive font-semibold text-sm px-6 py-3 rounded-full hover:bg-olive hover:text-white transition-colors focus-visible:outline-2 focus-visible:outline-olive whitespace-nowrap"
          >
            Avaliar no Google
          </a>
        </motion.div>

      </div>
    </section>
  )
}
