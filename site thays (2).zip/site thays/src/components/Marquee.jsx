const ITEMS = [
  'NUTRIÇÃO CLÍNICA',
  'ESPORTIVA',
  'SAÚDE DA MULHER',
  'LIPEDEMA & ENDOMETRIOSE',
  'SUPORTE GLP-1',
  'MACEIÓ & ONLINE',
]

const content = [...ITEMS, ...ITEMS].join(' · ')

export default function Marquee() {
  return (
    <div
      className="bg-olive py-4 overflow-hidden"
      aria-label="Áreas de atuação"
      role="marquee"
    >
      <div className="marquee-track">
        {[...Array(4)].map((_, i) => (
          <span
            key={i}
            className="text-xs sm:text-sm font-semibold tracking-widest text-white/90 uppercase whitespace-nowrap pr-10"
            aria-hidden={i > 0}
          >
            {ITEMS.join(' · ')} ·&nbsp;
          </span>
        ))}
      </div>
    </div>
  )
}
