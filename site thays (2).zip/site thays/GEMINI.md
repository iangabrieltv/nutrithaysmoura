# Diretrizes do Projeto — Site Nutricionista Thays Moura

1. **Idioma e Tom:** Todo o código visível ao usuário, textos, metadados SEO, `alt` de imagens e labels de acessibilidade devem estar em **português do Brasil (pt-BR)**, com tom humano, acolhedor, técnico e sem terrorismo nutricional.
2. **Fidelidade aos Ativos Reais:**
   - Use exclusivamente a logo oficial em `fotos/download.png` (verde-oliva `#404727`) e as fotografias reais em `fotos/`.
   - **Nunca invente** número de CRN, endereço físico, telefone/WhatsApp, anos de experiência, quantidade de pacientes ou depoimentos como se fossem reais sem confirmação explícita do usuário; use placeholders claramente marcados enquanto aguarda os dados finais.
3. **Proibição de Estética Genérica ("AI Slop" / Template Pronto):**
   - Proibido usar gradientes roxo/índigo, cinzas azulados frios, "3 cards centralizados idênticos com ícone no topo", ou imagens clichês (frutas recortadas flutuando, fita métrica, jaleco genérico).
   - Siga os tokens e o ritmo visual definidos nas skills `.agents/skills/thays-moura-brand-system` e `.agents/skills/editorial-nutrition-ux`.
4. **Qualidade de Engenharia:**
   - Componentes semânticos, responsivos (mobile-first 375px até 1440px+), foco visível (`focus-visible`), e respeito a `prefers-reduced-motion`.
